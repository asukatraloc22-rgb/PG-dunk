import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface Exercise {
  name: string;
  sets: number;
  reps: string;
  restSeconds: number;
  notes: string;
}

interface WorkoutRequest {
  focusArea?: string;
  duration?: number;
  difficulty?: string;
  specificGoals?: string[];
  currentPhase?: string;
  limitations?: string[];
  energyLevel?: number;
  language?: string;
}

const OPENAI_API_KEY = Deno.env.get('OPENAI_API_KEY');

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  if (req.method !== "POST") {
    return new Response(
      JSON.stringify({ error: "Method not allowed" }),
      { status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  if (!OPENAI_API_KEY) {
    return new Response(
      JSON.stringify({ error: "OPENAI_API_KEY not configured. Please add your OpenAI API key to Supabase edge function secrets." }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  try {
    const body: WorkoutRequest = await req.json();

    const {
      focusArea = "vertical jump",
      duration = 60,
      difficulty = "intermediate",
      specificGoals = [],
      currentPhase = "force development",
      limitations = [],
      energyLevel = 7,
      language = "fr"
    } = body;

    const systemPrompt = language === "fr"
      ? `Tu es un coach expert en développement du saut vertical pour joueurs de basket. Tu crées des programmes d'entraînement personnalisés basés sur les principes scientifiques du jump training.

RÈGLES IMPORTANTES:
1. Chaque workout doit inclure: échauffement dynamique (10-15 min), bloc principal, travail accessoire/core, retour au calme
2. Adapte le volume à l'énergie déclarée (1-10)
3. Structure les exercices de haute intensité avant la fatigue
4. Inclue les temps de repos spécifiques pour chaque exercice
5. Privilégie la qualité sur la quantité

Retourne TOUJOURS un JSON valide avec cette structure exacte (sans markdown, juste le JSON):
{
  "title": "string (nom du workout)",
  "description": "string (description en 2-3 phrases)",
  "focusArea": "string",
  "difficulty": "beginner|intermediate|elite",
  "durationMinutes": number,
  "exercises": [
    {
      "name": "string",
      "sets": number,
      "reps": "string (ex: '5-8 reps' ou '30 sec')",
      "restSeconds": number,
      "notes": "string (conseils d'exécution)"
    }
  ]
}`
      : `You are an expert vertical jump coach for basketball players. Create personalized training programs based on scientific jump training principles.

IMPORTANT RULES:
1. Each workout must include: dynamic warmup (10-15 min), main block, accessory/core work, cooldown
2. Adapt volume to declared energy level (1-10)
3. Structure high-intensity exercises before fatigue
4. Include specific rest times for each exercise
5. Quality over quantity

Always return valid JSON with this exact structure (no markdown, just JSON):
{
  "title": "string (workout name)",
  "description": "string (2-3 sentence description)",
  "focusArea": "string",
  "difficulty": "beginner|intermediate|elite",
  "durationMinutes": number,
  "exercises": [
    {
      "name": "string",
      "sets": number,
      "reps": "string (ex: '5-8 reps' or '30 sec')",
      "restSeconds": number,
      "notes": "string (execution tips)"
    }
  ]
}`;

    const userPrompt = language === "fr"
      ? `Crée un workout basé sur:
- Focus: ${focusArea}
- Durée cible: ${duration} minutes
- Niveau: ${difficulty}
- Objectifs spécifiques: ${specificGoals.length > 0 ? specificGoals.join(', ') : 'non spécifiés'}
- Phase actuelle: ${currentPhase}
- Limitations/blessures: ${limitations.length > 0 ? limitations.join(', ') : 'aucune'}
- Niveau d'énergie aujourd'hui: ${energyLevel}/10

Génère uniquemement le JSON, sans texte avant ou après.`
      : `Create a workout based on:
- Focus: ${focusArea}
- Target duration: ${duration} minutes
- Level: ${difficulty}
- Specific goals: ${specificGoals.length > 0 ? specificGoals.join(', ') : 'none specified'}
- Current phase: ${currentPhase}
- Limitations/injuries: ${limitations.length > 0 ? limitations.join(', ') : 'none'}
- Energy level today: ${energyLevel}/10

Generate only the JSON, no text before or after.`;

    const response = await fetch(
      "https://api.openai.com/v1/chat/completions",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${OPENAI_API_KEY}`
        },
        body: JSON.stringify({
          model: "gpt-4o-mini",
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: userPrompt }
          ],
          temperature: 0.7,
          max_tokens: 2048,
          response_format: { type: "json_object" }
        })
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      console.error("OpenAI API error:", errorText);
      return new Response(
        JSON.stringify({ error: "AI generation failed", details: errorText }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const openaiData = await response.json();
    const generatedText = openaiData.choices?.[0]?.message?.content;

    if (!generatedText) {
      return new Response(
        JSON.stringify({ error: "No content generated" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Parse and validate the response
    let workout;
    try {
      workout = JSON.parse(generatedText);
    } catch (e) {
      console.error("Failed to parse OpenAI response:", generatedText);
      return new Response(
        JSON.stringify({ error: "Invalid AI response format", raw: generatedText }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(
      JSON.stringify({ workout }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (err) {
    console.error("Edge function error:", err);
    return new Response(
      JSON.stringify({ error: err.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
